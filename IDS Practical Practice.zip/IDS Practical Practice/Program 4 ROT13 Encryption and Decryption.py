def rot13(text):
    result = ""
    for ch in text:
        if ch.isalpha():
            if 'A' <= ch <= 'Z':
                result += chr((ord(ch) - ord('A') + 13) % 26 + ord('A'))
            elif 'a' <= ch <= 'z':
                result += chr((ord(ch) - ord('a') + 13) % 26 + ord('a'))
            else:
                result += ch
    return result

plaintext = input("Enter the plaintext: ")

#Encrypt the plaintext using ROT13
ciphertext = rot13(plaintext)
decrypted_text = rot13(ciphertext)

print("Ciphertext: ", ciphertext)
print("Decrypted text: ", decrypted_text)
