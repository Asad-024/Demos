def cipher_block_encrypt(block,key_bytes):
    return block ^ key_bytes

#ECB Mode Encryption
def ecb_encrypt(plaintext,key):
    ciphertext = []
    for char in plaintext:
        block = ord(char)
        key_bytes = int.from_bytes(key.encode(), 'big')
        cipher_block = cipher_block_encrypt(block, key_bytes)
        ciphertext.append(cipher_block)
    return ciphertext

#ECB Mode Decryption with Initialization Vector (IV)
def ecb_decrypt(ciphertext,key):
    decrypted_text = ""
    for cipher_block in ciphertext:
        key_bytes = int.from_bytes(key.encode(), 'big')
        decrypted_block = cipher_block_encrypt(cipher_block, key_bytes)
        decrypted_text += chr(decrypted_block)
    return decrypted_text

#Main Program
plaintext = input("Enter plaintext message: ")
key = input("Enter symmetric key: ")
iv = input("Enter initialization vector (IV): ")

print("Plaintext: ", plaintext)
print("Key Length in bits: ", len(key) * 8)

#Encrypting using ECB mode
ciphertext_ecb = ecb_encrypt(plaintext, key)
print("Encrypted text (ECB): ", ciphertext_ecb)

#Decrypting using ECB mode
decrypted_text_ecb = ecb_decrypt(ciphertext_ecb, key)
print("Decrypted text (ECB): ", decrypted_text_ecb)