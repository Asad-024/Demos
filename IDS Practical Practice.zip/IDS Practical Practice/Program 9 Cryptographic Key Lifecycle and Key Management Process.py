import secrets
import time


class KeyManager:
    def __init__(self):
        self.key_store = {}
        self.backups = {}

    # 1. Generating Keys
    def generate_key(self, key_id, bit_length=128):
        num_bytes = bit_length // 8
        raw_key = secrets.token_hex(num_bytes)

        self.key_store[key_id] = {
            "key_data": raw_key,
            "status": "ACTIVE",
            "bit_length": bit_length,
            "created_at": time.ctime()
        }

        print(f"[GENERATED] Key '{key_id}' ({bit_length}-bit): {raw_key}")

    # 2. Backing up Keys
    def backup_key(self, key_id):
        if key_id in self.key_store:
            self.backups[key_id] = self.key_store[key_id].copy()
            print(f"[BACKUP] Key '{key_id}' successfully saved to secure backup.")

    # 3. Verifying & Using Keys
    def use_key(self, key_id):
        key_info = self.key_store.get(key_id)

        if not key_info:
            print(f"[ERROR] Key '{key_id}' does not exist.")
            return None

        if key_info["status"] != "ACTIVE":
            print(f"[ACCESS DENIED] Key '{key_id}' status is '{key_info['status']}'. Cannot use!")
            return None

        print(f"[USING] Verified & Active key '{key_id}' loaded for crypto operations.")
        return key_info["key_data"]

    # 4. Updating / Rotating Keys
    def update_key(self, key_id):
        print(f"[UPDATE] Rotating Key '{key_id}'...")
        self.generate_key(key_id, self.key_store[key_id]["bit_length"])

    # 5. Handling Compromised Keys
    def mark_compromised(self, key_id):
        if key_id in self.key_store:
            self.key_store[key_id]["status"] = "COMPROMISED"
            print(f"[WARNING] Key '{key_id}' marked as COMPROMISED! Access revoked.")

    # 6. Destroying Keys
    def destroy_key(self, key_id):
        if key_id in self.key_store:
            self.key_store[key_id]["key_data"] = "0000000000000000"
            self.key_store[key_id]["status"] = "DESTROYED"
            del self.key_store[key_id]
            print(f"[DESTROYED] Key '{key_id}' zeroed out and removed from store.")


# Main Lifecycle Demonstration
print("--- 3. Cryptographic Key Lifecycle Management ---")

kms = KeyManager()

# Phase 1: Generation & Backup
print("\n-- Phase 1: Generation & Backup --")
kms.generate_key("Session_Key_01", bit_length=128)
kms.backup_key("Session_Key_01")

# Phase 2: Usage & Verification
print("\n-- Phase 2: Usage & Verification --")
kms.use_key("Session_Key_01")

# Phase 3: Updating / Rotation
print("\n-- Phase 3: Updating / Rotation --")
kms.update_key("Session_Key_01")

# Phase 4: Compromise Event
print("\n-- Phase 4: Compromise Event --")
kms.mark_compromised("Session_Key_01")
kms.use_key("Session_Key_01")

# Phase 5: Destruction
print("\n-- Phase 5: Destruction --")
kms.destroy_key("Session_Key_01")