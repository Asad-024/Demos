import math

def gcd(a,b):
    while b != 0:
        a , b = b, a % b
    return a

def modular_inverse(e,phi):
    for d in range(1, phi):
        if (e * d) % phi == 1:
            return d
    return None

p = 61
q = 53
n = p * q

phi = (p - 1) * (q - 1)
e = 17

if gcd(e, phi) != 1:
    print("e and phi are not coprime. Choose a different e.")
else:
    if modular_inverse(e, phi) is None:
        print("No modular inverse found. Choose a different e.")
    else:
        print("RSA Key Generation Successful!")

print("GCD of e and phi: ", gcd(e, phi))
print("Modular inverse of e mod phi: ", modular_inverse(e, phi))
print("Public Key (n, e): (", n, ",", e, ")")
print("Private Key (n, d): (", n, ",", modular_inverse(e, phi), ")")

plaintext = input("Enter plaintext message: ")
encrypted_text = []

for ch in plaintext:
    message_number = ord(ch)
    cipher_number = pow(message_number, e, n)
    encrypted_text.append(cipher_number)

print("Encrypted text:", encrypted_text)

decrypted_text = ""

for cipher_number in encrypted_text:
    message_number = pow(cipher_number, modular_inverse(e, phi), n)
    decrypted_text += chr(message_number)

print("Decrypted text:", decrypted_text)
