def symmetric_key_encryption(plaintext,key):
    ciphertext = []
    key_length = len(key)

    #Using Simple XOR operation for symmetric encryption
    for index , char in enumerate(plaintext):
        key_char = key[index % key_length]
        cipher_char = chr(ord(char) ^ ord(key_char))
        ciphertext.append(cipher_char)
    return ciphertext

def symmetric_key_decryption(ciphertext,key):
    decrypted_text = ""
    key_length = len(key)

    #Using Simple XOR operation for symmetric decryption
    for index , char in enumerate(ciphertext):
        key_char = key[index % key_length]
        decrypted_char = chr(ord(char) ^ ord(key_char))
        decrypted_text += decrypted_char
    return decrypted_text

#Main Program
plaintext = input("Enter plaintext message: ")
key = input("Enter symmetric key: ")

key_length = len(key)
key_bits = key_length * 8

print("Key Length in bits: ", key_bits)
print("Key Length in bytes: ", key_length)

ciphertext = symmetric_key_encryption(plaintext,key)
decrypted_text = symmetric_key_decryption(ciphertext,key)

print("Encrypted text: ", ''.join(ciphertext))
print("Decrypted text: ", decrypted_text)
