algorithm = input("Enter the algorithm (AES, DES, RSA): ")
key_length = int(input("Enter the key length (in bits): "))

key_space = 2 ** key_length

print("\n ---Key Length and Key Space Calculator---")
print("Algorithm: ", algorithm)
print("Key Length: ", key_length, "bits")
print("Key Space: ", key_space, "possible keys")

if key_length < 128:
    print("Vulnerability: The key length is considered weak and may be vulnerable to brute-force attacks.")
else:
    print("Vulnerability: The key length is considered strong and provides a good level of security against brute-force attacks.")