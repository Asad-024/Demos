def encrypt(text,key):
    result = ""
    for char in text:
        if char.isalpha():
            num = ord(char) - ord('A')
            encrypted_num = (num * key) % 26
            result += chr(encrypted_num + ord('A'))
        else:
            result += char
    return result

def decrypt(ciphertext,key):
    result = ""
    inverse_key = 21
    for char in ciphertext:
        if char.isalpha():
            num = ord(char) - ord('A')
            decrypted_num = (num * inverse_key) % 26
            result += chr(decrypted_num + ord('A'))
        else:
            result += char
    return result

plaintext = input("Enter the plaintext: ")
key = int(input("Enter the key (must be coprime with 26): "))

encrypted_text = encrypt(plaintext,key)
decrypted_text = decrypt(encrypted_text,key)

print("Encrypted text: ", encrypted_text)
print("Decrypted text: ", decrypted_text)