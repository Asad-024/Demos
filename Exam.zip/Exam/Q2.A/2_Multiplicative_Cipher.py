def encrypt(text,key):
    result = ""
    for char in text:
        if char.isalpha():
            num = ord(char) - ord('A')
            encrypted_num = (num * key) % 26
            result += chr(encrypted_num + ord('A'))
        else:
            result += char
    return result



plaintext = input("Enter plaintext: ")
key = int(input("Enter the key:"))

encrypted_text = encrypt(plaintext,key)
print("Encrypted text: ", encrypted_text)
